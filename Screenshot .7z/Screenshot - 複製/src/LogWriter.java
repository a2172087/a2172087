import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LogWriter {
    //private static final String LOG_FOLDER = "M:\\Q200\\02 QE Personal Data\\Racky\\Log History\\Screenshot";
    private static final String LOG_FOLDER = "M:\\QA_Program_Raw_Data\\Log History\\Screenshot";

    public static void saveLog() {
        try {
            String username = getUsername();
            String currentDateTime = getCurrentDateTime();
            String logMessage = currentDateTime + " " + username + " Open\n";

            Path logFolderPath = Paths.get(LOG_FOLDER);
            Files.createDirectories(logFolderPath);

            Path logFilePath = Paths.get(LOG_FOLDER, username + ".txt");
            Files.write(logFilePath, logMessage.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String getUsername() {
        try {
            InetAddress addr = InetAddress.getLocalHost();
            String hostname = addr.getHostName();
            String username = hostname.split("\\.")[0];
    
            // 檢查使用者名稱是否包含指定的值
            String[] restrictedUsernames = {"A005239", "A005359", "A005492", "A005573", "A005715", "A005721", "A005844", "A005943", "A005950", "A005958", "A005959", "A005965", 
            "A005980", "A005986", "A006098", "A006149", "A006172", "A006204", "A006209", "A0733", "A0888", "A2830", "A3003", "A3004", "A3211", "A3933", "A4505", "A4895",
            "A4975", "A4987", "A4997", "A5065"};
            for (String restrictedUsername : restrictedUsernames) {
                if (username.contains(restrictedUsername)) {
                    showMessageBox("warnings", "Activation authority not obtained, please contact #1082 Racky");
                    System.exit(0);
                }
            }
    
            return username;
        } catch (UnknownHostException e) {
            return "Unknown";
        }
    }
    
    private static void showMessageBox(String title, String message) {
        javax.swing.JOptionPane.showMessageDialog(null, message, title, javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }

    private static String getCurrentDateTime() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return now.format(formatter);
    }
}