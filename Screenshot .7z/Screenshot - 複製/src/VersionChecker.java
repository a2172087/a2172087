import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class VersionChecker {
    //private static final String APP_DIR = "M:\\Q200\\02 QE Personal Data\\Racky\\Apps";
    private static final String APP_DIR = "M:\\QA_Program_Raw_Data\\Apps";
    private static final int CURRENT_VERSION = 12;

    public static void checkVersion() {
        try {
            File appDir = new File(APP_DIR);
            if (!appDir.exists()) {
                showMessageBox("warnings", "Activation authority not obtained, please apply M:\\QA_Program_Raw_Data and contact #1082 Racky");
                System.exit(0);
            }

            int maxVersion = getMaxVersion(appDir);
            if (maxVersion == -1) {
                showMessageBox("warnings", "Software update in progress, please try again later, or contact #1082 Racky");
                System.exit(0);
            } else if (maxVersion > CURRENT_VERSION) {
                showMessageBox("warnings", "Please update to the latest version");
                openDirectory(APP_DIR);
                System.exit(0);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static int getMaxVersion(File dir) throws IOException {
        int maxVersion = -1;
        try (Stream<Path> paths = Files.walk(Paths.get(dir.getAbsolutePath()))) {
            maxVersion = paths
                    .map(Path::getFileName)
                    .map(Path::toString)
                    .filter(name -> name.startsWith("Screenshot_V") && name.endsWith(".exe"))
                    .map(name -> {
                        Matcher matcher = Pattern.compile("Screenshot_V(\\d+)\\.exe").matcher(name);
                        if (matcher.find()) {
                            return Integer.parseInt(matcher.group(1));
                        } else {
                            return -1;
                        }
                    })
                    .filter(version -> version != -1)
                    .max(Integer::compareTo)
                    .orElse(-1);
        }
        return maxVersion;
    }

    private static void showMessageBox(String title, String message) {
        javax.swing.JOptionPane.showMessageDialog(null, message, title, javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }

    private static void openDirectory(String dirPath) {
        try {
            Runtime.getRuntime().exec("explorer.exe " + dirPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}