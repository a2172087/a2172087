public class App {
    public static void main(String[] args) {
        VersionChecker.checkVersion();
        LogWriter.saveLog();
        SnipSketchLauncher.launchSnipSketch();
    }
}