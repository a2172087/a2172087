import java.io.IOException;

public class SnipSketchLauncher {
    public static void launchSnipSketch() {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder("explorer", "ms-screenclip:");
            processBuilder.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}